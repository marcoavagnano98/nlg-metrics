import os
from .questeval_metric import QuestEval
DIR = os.path.dirname(__file__)
__version__ = "0.2.4"
