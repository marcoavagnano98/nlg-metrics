
#nltk.download('wordnet')
